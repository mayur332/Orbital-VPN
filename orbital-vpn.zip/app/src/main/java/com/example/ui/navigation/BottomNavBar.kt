package com.example.ui.navigation

import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Map
import androidx.compose.material.icons.outlined.Public
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.NavTab
import com.example.ui.theme.CardBorderDark
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.OrbitalPurple
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary

@Composable
fun BottomNavBar(
    activeTab: NavTab,
    onTabSelected: (NavTab) -> Unit,
    modifier: Modifier = Modifier
) {
    NavigationBar(
        containerColor = SurfaceDark,
        contentColor = TextPrimary,
        tonalElevation = 8.dp,
        modifier = modifier
            .navigationBarsPadding()
            .testTag("bottom_navigation_bar")
    ) {
        // Home Tab
        NavigationBarItem(
            selected = activeTab == NavTab.HOME,
            onClick = { onTabSelected(NavTab.HOME) },
            icon = {
                Icon(
                    imageVector = if (activeTab == NavTab.HOME) Icons.Default.Home else Icons.Outlined.Home,
                    contentDescription = "Home"
                )
            },
            label = {
                Text(
                    text = "Home",
                    fontSize = 11.sp,
                    fontWeight = if (activeTab == NavTab.HOME) FontWeight.Bold else FontWeight.Normal
                )
            },
            colors = navItemColors(),
            modifier = Modifier.testTag("nav_tab_home")
        )

        // Servers Tab
        NavigationBarItem(
            selected = activeTab == NavTab.SERVERS,
            onClick = { onTabSelected(NavTab.SERVERS) },
            icon = {
                Icon(
                    imageVector = if (activeTab == NavTab.SERVERS) Icons.Default.Public else Icons.Outlined.Public,
                    contentDescription = "Servers"
                )
            },
            label = {
                Text(
                    text = "Servers",
                    fontSize = 11.sp,
                    fontWeight = if (activeTab == NavTab.SERVERS) FontWeight.Bold else FontWeight.Normal
                )
            },
            colors = navItemColors(),
            modifier = Modifier.testTag("nav_tab_servers")
        )

        // Map Tab
        NavigationBarItem(
            selected = activeTab == NavTab.MAP,
            onClick = { onTabSelected(NavTab.MAP) },
            icon = {
                Icon(
                    imageVector = if (activeTab == NavTab.MAP) Icons.Default.Map else Icons.Outlined.Map,
                    contentDescription = "Map"
                )
            },
            label = {
                Text(
                    text = "Map",
                    fontSize = 11.sp,
                    fontWeight = if (activeTab == NavTab.MAP) FontWeight.Bold else FontWeight.Normal
                )
            },
            colors = navItemColors(),
            modifier = Modifier.testTag("nav_tab_map")
        )

        // Settings Tab
        NavigationBarItem(
            selected = activeTab == NavTab.SETTINGS,
            onClick = { onTabSelected(NavTab.SETTINGS) },
            icon = {
                Icon(
                    imageVector = if (activeTab == NavTab.SETTINGS) Icons.Default.Settings else Icons.Outlined.Settings,
                    contentDescription = "Settings"
                )
            },
            label = {
                Text(
                    text = "Settings",
                    fontSize = 11.sp,
                    fontWeight = if (activeTab == NavTab.SETTINGS) FontWeight.Bold else FontWeight.Normal
                )
            },
            colors = navItemColors(),
            modifier = Modifier.testTag("nav_tab_settings")
        )
    }
}

@Composable
private fun navItemColors() = NavigationBarItemDefaults.colors(
    selectedIconColor = ElectricCyan,
    selectedTextColor = ElectricCyan,
    indicatorColor = OrbitalPurple.copy(alpha = 0.35f),
    unselectedIconColor = TextMuted,
    unselectedTextColor = TextMuted
)
