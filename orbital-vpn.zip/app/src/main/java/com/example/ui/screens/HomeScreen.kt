package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.DataUsage
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ConnectionState
import com.example.data.NavTab
import com.example.ui.components.SpeedStatsCard
import com.example.ui.components.VpnPowerButton
import com.example.ui.theme.CardBorderDark
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.OrbitalPurple
import com.example.ui.theme.OrbitalPurpleGlow
import com.example.ui.theme.StatusGreen
import com.example.ui.theme.StatusYellow
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceDarkElevated
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.VpnUiState

@Composable
fun HomeScreen(
    uiState: VpnUiState,
    onToggleConnection: () -> Unit,
    onNavigateTab: (NavTab) -> Unit,
    formatDuration: (Int) -> String,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp)
            .testTag("home_screen_container")
    ) {
        // Top Header
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.linearGradient(
                                colors = listOf(OrbitalPurple, OrbitalPurpleGlow)
                            )
                        )
                ) {
                    Icon(
                        imageVector = Icons.Default.Security,
                        contentDescription = "Logo",
                        tint = ElectricCyan,
                        modifier = Modifier.size(22.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Text(
                        text = "Orbital VPN",
                        color = TextPrimary,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Protocol: ${uiState.selectedProtocol}",
                        color = TextMuted,
                        fontSize = 11.sp
                    )
                }
            }

            // Connection Status Pill
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(
                        when (uiState.connectionState) {
                            ConnectionState.CONNECTED -> StatusGreen.copy(alpha = 0.18f)
                            ConnectionState.CONNECTING -> StatusYellow.copy(alpha = 0.18f)
                            ConnectionState.DISCONNECTED -> CardBorderDark
                        }
                    )
                    .border(
                        width = 1.dp,
                        color = when (uiState.connectionState) {
                            ConnectionState.CONNECTED -> StatusGreen
                            ConnectionState.CONNECTING -> StatusYellow
                            ConnectionState.DISCONNECTED -> TextMuted.copy(alpha = 0.5f)
                        },
                        shape = RoundedCornerShape(20.dp)
                    )
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(
                                when (uiState.connectionState) {
                                    ConnectionState.CONNECTED -> StatusGreen
                                    ConnectionState.CONNECTING -> StatusYellow
                                    ConnectionState.DISCONNECTED -> TextMuted
                                }
                            )
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = when (uiState.connectionState) {
                            ConnectionState.CONNECTED -> "PROTECTED"
                            ConnectionState.CONNECTING -> "SECURING"
                            ConnectionState.DISCONNECTED -> "UNPROTECTED"
                        },
                        color = when (uiState.connectionState) {
                            ConnectionState.CONNECTED -> StatusGreen
                            ConnectionState.CONNECTING -> StatusYellow
                            ConnectionState.DISCONNECTED -> TextMuted
                        },
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.8.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Selected Server Banner Card
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(18.dp))
                .background(SurfaceDark)
                .border(1.dp, CardBorderDark, RoundedCornerShape(18.dp))
                .clickable { onNavigateTab(NavTab.SERVERS) }
                .padding(14.dp)
                .testTag("selected_server_banner")
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(SurfaceDarkElevated)
                    ) {
                        Text(text = uiState.selectedServer.flagEmoji, fontSize = 22.sp)
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Text(
                            text = "${uiState.selectedServer.country} (${uiState.selectedServer.city})",
                            color = TextPrimary,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Ping: ${uiState.selectedServer.pingMs} ms",
                                color = StatusGreen,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "• Load: ${uiState.selectedServer.loadPercent}%",
                                color = TextMuted,
                                fontSize = 11.sp
                            )
                        }
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "Change",
                        color = ElectricCyan,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Icon(
                        imageVector = Icons.Default.ChevronRight,
                        contentDescription = "Change Server",
                        tint = ElectricCyan,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Central Power Button
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.fillMaxWidth()
        ) {
            VpnPowerButton(
                connectionState = uiState.connectionState,
                onClick = onToggleConnection
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Live Speed Stats
        SpeedStatsCard(
            downloadSpeed = uiState.downloadSpeedMbps,
            uploadSpeed = uiState.uploadSpeedMbps,
            downloadHistory = uiState.downloadHistory,
            uploadHistory = uiState.uploadHistory
        )

        Spacer(modifier = Modifier.height(20.dp))

        // Connection Information Details Card
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(SurfaceDark)
                .border(1.dp, CardBorderDark, RoundedCornerShape(20.dp))
                .padding(16.dp)
        ) {
            Column {
                Text(
                    text = "SESSION INFORMATION",
                    color = TextMuted,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    // Timer Item
                    InfoDetailTile(
                        icon = Icons.Default.Timer,
                        label = "Connected Time",
                        value = formatDuration(uiState.connectedDurationSeconds),
                        tint = ElectricCyan,
                        modifier = Modifier.weight(1f)
                    )

                    // IP Address Item
                    InfoDetailTile(
                        icon = Icons.Default.Public,
                        label = "Virtual IP",
                        value = uiState.activeIp,
                        tint = OrbitalPurpleGlow,
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    // Data Used
                    InfoDetailTile(
                        icon = Icons.Default.DataUsage,
                        label = "Data Transferred",
                        value = if (uiState.connectionState == ConnectionState.CONNECTED) {
                            String.format("%.2f MB", uiState.totalDataUsedMb)
                        } else "0.0 MB",
                        tint = StatusGreen,
                        modifier = Modifier.weight(1f)
                    )

                    // Encryption standard
                    InfoDetailTile(
                        icon = Icons.Default.Lock,
                        label = "Encryption",
                        value = "AES-256-GCM",
                        tint = StatusYellow,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }
}

@Composable
private fun InfoDetailTile(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    value: String,
    tint: androidx.compose.ui.graphics.Color,
    modifier: Modifier = Modifier
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = modifier.padding(vertical = 4.dp)
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(32.dp)
                .clip(CircleShape)
                .background(tint.copy(alpha = 0.15f))
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = tint,
                modifier = Modifier.size(16.dp)
            )
        }

        Spacer(modifier = Modifier.width(10.dp))

        Column {
            Text(
                text = label,
                color = TextMuted,
                fontSize = 10.sp
            )
            Text(
                text = value,
                color = TextPrimary,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
