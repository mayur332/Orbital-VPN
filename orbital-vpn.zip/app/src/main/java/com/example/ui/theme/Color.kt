package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Purple Palette
val OrbitalPurple = Color(0xFF6D28D9)
val OrbitalPurpleLight = Color(0xFF7C3AED)
val OrbitalPurpleDark = Color(0xFF4C1D95)
val OrbitalPurpleGlow = Color(0xFFA78BFA)

// Status & Accent Colors
val ElectricCyan = Color(0xFF22D3EE)
val ElectricCyanDark = Color(0xFF0891B2)
val StatusGreen = Color(0xFF10B981)
val StatusGreenGlow = Color(0xFF34D399)
val StatusYellow = Color(0xFFF59E0B)
val StatusRed = Color(0xFFEF4444)

// Sophisticated Dark Theme Surfaces
val BackgroundDark = Color(0xFF0F0F12)
val SurfaceDark = Color(0xFF1A1A22)
val SurfaceDarkElevated = Color(0xFF242430)
val CardBorderDark = Color(0x12FFFFFF)
val CardBorderGlow = Color(0xFF3B286D)

// Text Colors
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
