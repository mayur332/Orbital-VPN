package com.example.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Place
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ConnectionState
import com.example.data.ServerLocation
import com.example.ui.theme.CardBorderDark
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.OrbitalPurple
import com.example.ui.theme.OrbitalPurpleGlow
import com.example.ui.theme.StatusGreen
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceDarkElevated
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlin.math.pow
import kotlin.math.sqrt

@Composable
fun InteractiveWorldMap(
    servers: List<ServerLocation>,
    selectedServer: ServerLocation,
    connectionState: ConnectionState,
    highlightedServer: ServerLocation?,
    onSelectServer: (ServerLocation) -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "map_pulse")
    val pulseRadius by infiniteTransition.animateFloat(
        initialValue = 8f,
        targetValue = 24f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulse_radius"
    )

    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.8f,
        targetValue = 0.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulse_alpha"
    )

    val activeNode = highlightedServer ?: selectedServer

    Box(
        modifier = modifier
            .fillMaxSize()
            .testTag("interactive_world_map_container")
    ) {
        // World Map Canvas
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(servers) {
                    detectTapGestures { tapOffset ->
                        // Detect node click based on tap distance
                        val widthPx = size.width
                        val heightPx = size.height

                        var closestServer: ServerLocation? = null
                        var minDistance = Float.MAX_VALUE

                        servers.forEach { server ->
                            val x = server.mapXRatio * widthPx
                            val y = server.mapYRatio * heightPx
                            val dist = sqrt((tapOffset.x - x).pow(2) + (tapOffset.y - y).pow(2))
                            if (dist < minDistance && dist < 100f) { // 100px touch radius
                                minDistance = dist
                                closestServer = server
                            }
                        }

                        closestServer?.let { onSelectServer(it) }
                    }
                }
        ) {
            val widthPx = size.width
            val heightPx = size.height

            // 1. Draw Grid Lines (Latitude & Longitude lines for futuristic cyber map look)
            val gridColor = Color(0xFF1E1A34)
            for (i in 1..8) {
                val x = (widthPx / 9) * i
                drawLine(
                    color = gridColor,
                    start = Offset(x, 0f),
                    end = Offset(x, heightPx),
                    strokeWidth = 1f,
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f), 0f)
                )
            }
            for (j in 1..6) {
                val y = (heightPx / 7) * j
                drawLine(
                    color = gridColor,
                    start = Offset(0f, y),
                    end = Offset(widthPx, y),
                    strokeWidth = 1f,
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f), 0f)
                )
            }

            // 2. Draw Stylized World Continents
            drawContinentShapes(widthPx, heightPx)

            // 3. Draw Connection Arc from Home (e.g., US East) to Active Selected Server
            val homeServer = servers.find { it.id == "us_ny" } ?: servers.first()
            val homeX = homeServer.mapXRatio * widthPx
            val homeY = homeServer.mapYRatio * heightPx

            val targetX = activeNode.mapXRatio * widthPx
            val targetY = activeNode.mapYRatio * heightPx

            if (homeX != targetX || homeY != targetY) {
                val arcPath = Path().apply {
                    moveTo(homeX, homeY)
                    val midX = (homeX + targetX) / 2f
                    val midY = ((homeY + targetY) / 2f) - (heightPx * 0.15f)
                    quadraticTo(midX, midY, targetX, targetY)
                }

                val arcColor = if (connectionState == ConnectionState.CONNECTED) StatusGreen else ElectricCyan
                drawPath(
                    path = arcPath,
                    color = arcColor.copy(alpha = 0.8f),
                    style = Stroke(
                        width = 2.5.dp.toPx(),
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 8f), 0f)
                    )
                )
            }

            // 4. Draw Server Nodes (Pulsing glowing dots)
            servers.forEach { server ->
                val x = server.mapXRatio * widthPx
                val y = server.mapYRatio * heightPx

                val isCurrentSelected = server.id == selectedServer.id
                val isHighlighted = server.id == activeNode.id

                val nodeColor = when {
                    isCurrentSelected && connectionState == ConnectionState.CONNECTED -> StatusGreen
                    isCurrentSelected -> ElectricCyan
                    isHighlighted -> OrbitalPurpleGlow
                    else -> Color(0xFF6B5B95)
                }

                // Outer pulsing circle for active node
                if (isHighlighted || isCurrentSelected) {
                    drawCircle(
                        color = nodeColor.copy(alpha = pulseAlpha),
                        radius = pulseRadius * 1.5f,
                        center = Offset(x, y)
                    )
                }

                // Node Base Circle
                drawCircle(
                    color = nodeColor,
                    radius = if (isHighlighted || isCurrentSelected) 9.dp.toPx() else 5.dp.toPx(),
                    center = Offset(x, y)
                )

                // White Center Dot
                drawCircle(
                    color = Color.White,
                    radius = if (isHighlighted || isCurrentSelected) 4.dp.toPx() else 2.dp.toPx(),
                    center = Offset(x, y)
                )
            }
        }

        // Overlay Server Info Card at Bottom of Map
        Card(
            colors = CardDefaults.cardColors(containerColor = SurfaceDark),
            shape = RoundedCornerShape(20.dp),
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(16.dp)
                .border(1.dp, CardBorderDark, RoundedCornerShape(20.dp))
                .testTag("map_selected_server_card")
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(SurfaceDarkElevated)
                    ) {
                        Text(text = activeNode.flagEmoji, fontSize = 24.sp)
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "${activeNode.country} (${activeNode.city})",
                                color = TextPrimary,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(modifier = Modifier.height(2.dp))

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Place,
                                contentDescription = "IP",
                                tint = ElectricCyan,
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = activeNode.ipAddress,
                                color = TextSecondary,
                                fontSize = 12.sp
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "${activeNode.pingMs} ms",
                                color = if (activeNode.pingMs < 40) StatusGreen else TextMuted,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))

                Button(
                    onClick = { onSelectServer(activeNode) },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (activeNode.id == selectedServer.id && connectionState == ConnectionState.CONNECTED) StatusGreen else ElectricCyan,
                        contentColor = Color.Black
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.testTag("map_connect_button")
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (activeNode.id == selectedServer.id && connectionState == ConnectionState.CONNECTED) Icons.Default.CheckCircle else Icons.Default.FlashOn,
                            contentDescription = "Connect",
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (activeNode.id == selectedServer.id && connectionState == ConnectionState.CONNECTED) "Active" else "Connect",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

// Helper to draw continent vector silhouettes on map canvas
private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawContinentShapes(w: Float, h: Float) {
    val continentColor = Color(0xFF1E1834)

    // North America
    val naPath = Path().apply {
        moveTo(w * 0.12f, h * 0.20f)
        lineTo(w * 0.32f, h * 0.18f)
        lineTo(w * 0.35f, h * 0.35f)
        lineTo(w * 0.28f, h * 0.48f)
        lineTo(w * 0.20f, h * 0.45f)
        lineTo(w * 0.15f, h * 0.32f)
        close()
    }
    drawPath(naPath, continentColor)

    // South America
    val saPath = Path().apply {
        moveTo(w * 0.28f, h * 0.50f)
        lineTo(w * 0.38f, h * 0.52f)
        lineTo(w * 0.35f, h * 0.78f)
        lineTo(w * 0.30f, h * 0.82f)
        lineTo(w * 0.27f, h * 0.62f)
        close()
    }
    drawPath(saPath, continentColor)

    // Europe
    val euPath = Path().apply {
        moveTo(w * 0.46f, h * 0.22f)
        lineTo(w * 0.58f, h * 0.20f)
        lineTo(w * 0.56f, h * 0.38f)
        lineTo(w * 0.48f, h * 0.38f)
        close()
    }
    drawPath(euPath, continentColor)

    // Africa
    val afPath = Path().apply {
        moveTo(w * 0.46f, h * 0.40f)
        lineTo(w * 0.58f, h * 0.42f)
        lineTo(w * 0.55f, h * 0.72f)
        lineTo(w * 0.48f, h * 0.68f)
        close()
    }
    drawPath(afPath, continentColor)

    // Asia
    val asPath = Path().apply {
        moveTo(w * 0.58f, h * 0.18f)
        lineTo(w * 0.88f, h * 0.18f)
        lineTo(w * 0.85f, h * 0.48f)
        lineTo(w * 0.68f, h * 0.52f)
        lineTo(w * 0.60f, h * 0.40f)
        close()
    }
    drawPath(asPath, continentColor)

    // Australia
    val auPath = Path().apply {
        moveTo(w * 0.78f, h * 0.65f)
        lineTo(w * 0.90f, h * 0.65f)
        lineTo(w * 0.88f, h * 0.82f)
        lineTo(w * 0.76f, h * 0.80f)
        close()
    }
    drawPath(auPath, continentColor)
}
