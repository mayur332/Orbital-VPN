package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Icon
import androidx.compose.material3.RippleDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ConnectionState
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.OrbitalPurple
import com.example.ui.theme.OrbitalPurpleGlow
import com.example.ui.theme.StatusGreen
import com.example.ui.theme.StatusGreenGlow
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary

@Composable
fun VpnPowerButton(
    connectionState: ConnectionState,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "power_button_anim")

    // Pulse scale animation for connected or connecting
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = if (connectionState != ConnectionState.DISCONNECTED) 1.25f else 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    // Pulse alpha
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.5f,
        targetValue = 0.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulse_alpha"
    )

    // Rotation for connecting spinner
    val rotationAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing)
        ),
        label = "rotation_angle"
    )

    val activeGlowColor = when (connectionState) {
        ConnectionState.CONNECTED -> StatusGreen
        ConnectionState.CONNECTING -> ElectricCyan
        ConnectionState.DISCONNECTED -> OrbitalPurple
    }

    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .size(240.dp)
            .testTag("power_connect_button_container")
    ) {
        // Outer pulsing ring Canvas
        Canvas(modifier = Modifier.size(230.dp)) {
            if (connectionState != ConnectionState.DISCONNECTED) {
                drawCircle(
                    color = activeGlowColor.copy(alpha = pulseAlpha * 0.4f),
                    radius = (size.minDimension / 2) * pulseScale
                )
            }
            drawCircle(
                color = activeGlowColor.copy(alpha = 0.15f),
                radius = size.minDimension / 2
            )
        }

        // Connecting spinner ring
        if (connectionState == ConnectionState.CONNECTING) {
            Canvas(modifier = Modifier.size(190.dp)) {
                drawArc(
                    brush = Brush.sweepGradient(
                        listOf(ElectricCyan.copy(alpha = 0.1f), ElectricCyan, ElectricCyan.copy(alpha = 0.1f))
                    ),
                    startAngle = rotationAngle,
                    sweepAngle = 270f,
                    useCenter = false,
                    style = Stroke(width = 6.dp.toPx(), cap = StrokeCap.Round)
                )
            }
        }

        // Middle Glow Ring
        Box(
            modifier = Modifier
                .size(175.dp)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            activeGlowColor.copy(alpha = 0.25f),
                            Color.Transparent
                        )
                    )
                )
                .border(
                    width = 2.dp,
                    brush = Brush.linearGradient(
                        colors = when (connectionState) {
                            ConnectionState.CONNECTED -> listOf(StatusGreenGlow, StatusGreen)
                            ConnectionState.CONNECTING -> listOf(ElectricCyan, OrbitalPurpleGlow)
                            ConnectionState.DISCONNECTED -> listOf(OrbitalPurpleGlow.copy(alpha = 0.6f), Color.Transparent)
                        }
                    ),
                    shape = CircleShape
                )
        )

        // Main Inner Button Surface
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(150.dp)
                .clip(CircleShape)
                .background(
                    Brush.verticalGradient(
                        colors = when (connectionState) {
                            ConnectionState.CONNECTED -> listOf(
                                StatusGreen.copy(alpha = 0.35f),
                                SurfaceDark
                            )
                            ConnectionState.CONNECTING -> listOf(
                                ElectricCyan.copy(alpha = 0.3f),
                                SurfaceDark
                            )
                            ConnectionState.DISCONNECTED -> listOf(
                                OrbitalPurple.copy(alpha = 0.4f),
                                SurfaceDark
                            )
                        }
                    )
                )
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = ripple(bounded = true, color = activeGlowColor, radius = 75.dp),
                    onClick = onClick
                )
                .testTag("power_button_clickable")
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(12.dp)
            ) {
                Icon(
                    imageVector = if (connectionState == ConnectionState.CONNECTED) {
                        Icons.Default.Shield
                    } else {
                        Icons.Default.PowerSettingsNew
                    },
                    contentDescription = "Power Button",
                    tint = when (connectionState) {
                        ConnectionState.CONNECTED -> StatusGreenGlow
                        ConnectionState.CONNECTING -> ElectricCyan
                        ConnectionState.DISCONNECTED -> TextPrimary
                    },
                    modifier = Modifier
                        .size(44.dp)
                        .scale(if (connectionState == ConnectionState.CONNECTED) 1.1f else 1.0f)
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = when (connectionState) {
                        ConnectionState.CONNECTED -> "CONNECTED"
                        ConnectionState.CONNECTING -> "CONNECTING"
                        ConnectionState.DISCONNECTED -> "CONNECT"
                    },
                    color = when (connectionState) {
                        ConnectionState.CONNECTED -> StatusGreenGlow
                        ConnectionState.CONNECTING -> ElectricCyan
                        ConnectionState.DISCONNECTED -> TextPrimary
                    },
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.2.sp
                )

                Text(
                    text = when (connectionState) {
                        ConnectionState.CONNECTED -> "Tap to Stop"
                        ConnectionState.CONNECTING -> "Securing..."
                        ConnectionState.DISCONNECTED -> "Tap to Start"
                    },
                    color = TextMuted,
                    fontSize = 10.sp
                )
            }
        }
    }
}
