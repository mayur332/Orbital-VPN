package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.GppGood
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.RadioButtonChecked
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.WifiTethering
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.SplitTunnelDialog
import com.example.ui.theme.CardBorderDark
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.OrbitalPurple
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceDarkElevated
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.VpnUiState

@Composable
fun SettingsScreen(
    uiState: VpnUiState,
    onProtocolSelect: (String) -> Unit,
    onToggleKillSwitch: (Boolean) -> Unit,
    onToggleNetShield: (Boolean) -> Unit,
    onToggleAutoConnectWifi: (Boolean) -> Unit,
    onToggleSplitTunneling: (Boolean) -> Unit,
    onToggleAppSplitTunnel: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var showSplitTunnelDialog by remember { mutableStateOf(false) }

    if (showSplitTunnelDialog) {
        SplitTunnelDialog(
            apps = uiState.splitTunnelApps,
            isEnabled = uiState.splitTunnelingEnabled,
            onToggleEnabled = onToggleSplitTunneling,
            onToggleAppBypass = onToggleAppSplitTunnel,
            onDismiss = { showSplitTunnelDialog = false }
        )
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp)
            .testTag("settings_screen_container")
    ) {
        // Screen Header
        Text(
            text = "VPN Settings",
            color = TextPrimary,
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "Configure protocols, security features, and network behavior",
            color = TextMuted,
            fontSize = 12.sp
        )

        Spacer(modifier = Modifier.height(20.dp))

        // 1. Protocol Selection Section
        SectionTitle(title = "CONNECTION PROTOCOL")

        Spacer(modifier = Modifier.height(10.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(SurfaceDark)
                .border(1.dp, CardBorderDark, RoundedCornerShape(20.dp))
                .padding(16.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                uiState.protocols.forEach { protocol ->
                    val isSelected = protocol.name == uiState.selectedProtocol

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(if (isSelected) SurfaceDarkElevated else SurfaceDark)
                            .border(
                                width = 1.dp,
                                color = if (isSelected) ElectricCyan else CardBorderDark,
                                shape = RoundedCornerShape(14.dp)
                            )
                            .clickable { onProtocolSelect(protocol.name) }
                            .padding(12.dp)
                            .testTag("protocol_option_${protocol.name}")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            RadioButton(
                                selected = isSelected,
                                onClick = { onProtocolSelect(protocol.name) },
                                colors = RadioButtonDefaults.colors(
                                    selectedColor = ElectricCyan,
                                    unselectedColor = TextMuted
                                )
                            )

                            Spacer(modifier = Modifier.width(8.dp))

                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = protocol.title,
                                        color = TextPrimary,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    if (protocol.isRecommended) {
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(4.dp))
                                                .background(ElectricCyan.copy(alpha = 0.2f))
                                                .padding(horizontal = 6.dp, vertical = 2.dp)
                                        ) {
                                            Text(
                                                text = "FASTEST",
                                                color = ElectricCyan,
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                }
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = protocol.description,
                                    color = TextMuted,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // 2. Security Toggles Section
        SectionTitle(title = "SECURITY & PRIVACY")

        Spacer(modifier = Modifier.height(10.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(SurfaceDark)
                .border(1.dp, CardBorderDark, RoundedCornerShape(20.dp))
                .padding(16.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                // Kill Switch Toggle
                SettingSwitchRow(
                    icon = Icons.Default.Shield,
                    title = "Kill Switch",
                    description = "Block all internet traffic if the VPN connection drops unexpectedly",
                    checked = uiState.killSwitchEnabled,
                    onCheckedChange = onToggleKillSwitch,
                    testTag = "switch_kill_switch"
                )

                // NetShield Ad-Blocker
                SettingSwitchRow(
                    icon = Icons.Default.GppGood,
                    title = "NetShield Ad-Blocker",
                    description = "Block malware, intrusive advertisements, and online cross-site trackers",
                    checked = uiState.netShieldEnabled,
                    onCheckedChange = onToggleNetShield,
                    testTag = "switch_netshield"
                )

                // Auto-connect on Untrusted Wi-Fi
                SettingSwitchRow(
                    icon = Icons.Default.WifiTethering,
                    title = "Auto-Connect on Wi-Fi",
                    description = "Automatically launch VPN connection when joining open or public Wi-Fi networks",
                    checked = uiState.autoConnectWifi,
                    onCheckedChange = onToggleAutoConnectWifi,
                    testTag = "switch_autoconnect_wifi"
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // 3. Split Tunneling Section
        SectionTitle(title = "ADVANCED TUNNELING")

        Spacer(modifier = Modifier.height(10.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(SurfaceDark)
                .border(1.dp, CardBorderDark, RoundedCornerShape(20.dp))
                .padding(16.dp)
        ) {
            Column {
                SettingSwitchRow(
                    icon = Icons.Default.PhoneAndroid,
                    title = "Split Tunneling",
                    description = "Allow selected applications to bypass VPN and connect directly to the internet",
                    checked = uiState.splitTunnelingEnabled,
                    onCheckedChange = onToggleSplitTunneling,
                    testTag = "switch_split_tunneling"
                )

                val bypassedCount = uiState.splitTunnelApps.count { it.isBypassingVpn }

                Spacer(modifier = Modifier.height(14.dp))

                Button(
                    onClick = { showSplitTunnelDialog = true },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = SurfaceDarkElevated,
                        contentColor = ElectricCyan
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, CardBorderDark, RoundedCornerShape(12.dp))
                        .testTag("btn_configure_split_tunnel_apps")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "Configure Bypassed Apps ($bypassedCount Selected)",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Icon(
                            imageVector = Icons.Default.ChevronRight,
                            contentDescription = "Configure Apps",
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Diagnostic Footer
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(SurfaceDarkElevated)
                .padding(14.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Info,
                    contentDescription = "Info",
                    tint = TextMuted,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "Orbital Security Engine v3.4.1",
                        color = TextPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Zero-Logs Policy Verified • ChaCha20 / Poly1305 Cipher",
                        color = TextMuted,
                        fontSize = 10.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun SectionTitle(title: String) {
    Text(
        text = title,
        color = TextMuted,
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.sp
    )
}

@Composable
private fun SettingSwitchRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    description: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    testTag: String
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            verticalAlignment = Alignment.Top,
            modifier = Modifier.weight(1f)
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(OrbitalPurple.copy(alpha = 0.2f))
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = ElectricCyan,
                    modifier = Modifier.size(20.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column {
                Text(
                    text = title,
                    color = TextPrimary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = description,
                    color = TextMuted,
                    fontSize = 11.sp,
                    lineHeight = 15.sp
                )
            }
        }

        Spacer(modifier = Modifier.width(8.dp))

        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.Black,
                checkedTrackColor = ElectricCyan,
                uncheckedThumbColor = TextMuted,
                uncheckedTrackColor = SurfaceDarkElevated
            ),
            modifier = Modifier.testTag(testTag)
        )
    }
}
