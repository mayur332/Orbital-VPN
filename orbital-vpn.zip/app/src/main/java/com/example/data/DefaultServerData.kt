package com.example.data

object DefaultServerData {
    val initialServers = listOf(
        ServerLocation(
            id = "us_ny",
            country = "United States",
            city = "New York",
            flagEmoji = "🇺🇸",
            ipAddress = "185.220.101.5",
            pingMs = 28,
            loadPercent = 38,
            category = "Recommended",
            isPremium = false,
            isFavorite = true,
            mapXRatio = 0.28f,
            mapYRatio = 0.38f
        ),
        ServerLocation(
            id = "us_la",
            country = "United States",
            city = "Los Angeles",
            flagEmoji = "🇺🇸",
            ipAddress = "192.241.210.12",
            pingMs = 45,
            loadPercent = 52,
            category = "Streaming",
            isPremium = false,
            isFavorite = false,
            mapXRatio = 0.18f,
            mapYRatio = 0.42f
        ),
        ServerLocation(
            id = "nl_ams",
            country = "Netherlands",
            city = "Amsterdam",
            flagEmoji = "🇳🇱",
            ipAddress = "185.220.101.18",
            pingMs = 18,
            loadPercent = 24,
            category = "P2P",
            isPremium = false,
            isFavorite = true,
            mapXRatio = 0.51f,
            mapYRatio = 0.31f
        ),
        ServerLocation(
            id = "de_fra",
            country = "Germany",
            city = "Frankfurt",
            flagEmoji = "🇩🇪",
            ipAddress = "194.36.144.1",
            pingMs = 22,
            loadPercent = 31,
            category = "Recommended",
            isPremium = false,
            isFavorite = false,
            mapXRatio = 0.53f,
            mapYRatio = 0.33f
        ),
        ServerLocation(
            id = "jp_tyo",
            country = "Japan",
            city = "Tokyo",
            flagEmoji = "🇯🇵",
            ipAddress = "103.102.160.8",
            pingMs = 88,
            loadPercent = 64,
            category = "Streaming",
            isPremium = false,
            isFavorite = true,
            mapXRatio = 0.86f,
            mapYRatio = 0.42f
        ),
        ServerLocation(
            id = "in_bom",
            country = "India",
            city = "Mumbai",
            flagEmoji = "🇮🇳",
            ipAddress = "103.21.124.9",
            pingMs = 62,
            loadPercent = 48,
            category = "Recommended",
            isPremium = false,
            isFavorite = false,
            mapXRatio = 0.70f,
            mapYRatio = 0.52f
        ),
        ServerLocation(
            id = "uk_lon",
            country = "United Kingdom",
            city = "London",
            flagEmoji = "🇬🇧",
            ipAddress = "185.120.32.4",
            pingMs = 24,
            loadPercent = 42,
            category = "Streaming",
            isPremium = false,
            isFavorite = false,
            mapXRatio = 0.48f,
            mapYRatio = 0.29f
        ),
        ServerLocation(
            id = "sg_sin",
            country = "Singapore",
            city = "Singapore",
            flagEmoji = "🇸🇬",
            ipAddress = "128.199.200.11",
            pingMs = 74,
            loadPercent = 55,
            category = "P2P",
            isPremium = false,
            isFavorite = false,
            mapXRatio = 0.78f,
            mapYRatio = 0.60f
        ),
        ServerLocation(
            id = "fr_par",
            country = "France",
            city = "Paris",
            flagEmoji = "🇫🇷",
            ipAddress = "51.159.22.90",
            pingMs = 26,
            loadPercent = 29,
            category = "Recommended",
            isPremium = false,
            isFavorite = false,
            mapXRatio = 0.50f,
            mapYRatio = 0.33f
        ),
        ServerLocation(
            id = "ca_tor",
            country = "Canada",
            city = "Toronto",
            flagEmoji = "🇨🇦",
            ipAddress = "142.93.150.2",
            pingMs = 34,
            loadPercent = 40,
            category = "Free",
            isPremium = false,
            isFavorite = false,
            mapXRatio = 0.27f,
            mapYRatio = 0.33f
        ),
        ServerLocation(
            id = "au_syd",
            country = "Australia",
            city = "Sydney",
            flagEmoji = "🇦🇺",
            ipAddress = "139.99.140.77",
            pingMs = 120,
            loadPercent = 45,
            category = "Streaming",
            isPremium = true,
            isFavorite = false,
            mapXRatio = 0.88f,
            mapYRatio = 0.78f
        )
    )

    val defaultProtocols = listOf(
        ProtocolOption(
            name = "WireGuard",
            title = "WireGuard (Recommended)",
            description = "Next-generation protocol delivering maximum speed, ultra-low latency & 256-bit ChaCha20 encryption.",
            isRecommended = true
        ),
        ProtocolOption(
            name = "OpenVPN (UDP)",
            title = "OpenVPN (UDP)",
            description = "High-speed protocol optimized for streaming, gaming, and real-time data transfers.",
            isRecommended = false
        ),
        ProtocolOption(
            name = "OpenVPN (TCP)",
            title = "OpenVPN (TCP)",
            description = "Ultra-reliable connection protocol designed to bypass strict firewalls and network restrictions.",
            isRecommended = false
        ),
        ProtocolOption(
            name = "Stealth",
            title = "Stealth (Obfuscated)",
            description = "Masks VPN traffic as standard TLS HTTPS web browsing to bypass censorship and DPI filters.",
            isRecommended = false
        )
    )

    val defaultApps = listOf(
        AppInfo("com.android.chrome", "Google Chrome", false),
        AppInfo("com.google.android.youtube", "YouTube", false),
        AppInfo("com.spotify.music", "Spotify", true),
        AppInfo("com.netflix.mediaclient", "Netflix", false),
        AppInfo("com.mybank.app", "Mobile Banking App", true),
        AppInfo("com.whatsapp", "WhatsApp", false),
        AppInfo("org.telegram.messenger", "Telegram", false)
    )
}
