package com.example.data

enum class ConnectionState {
    DISCONNECTED,
    CONNECTING,
    CONNECTED
}

data class ServerLocation(
    val id: String,
    val country: String,
    val city: String,
    val flagEmoji: String,
    val ipAddress: String,
    val pingMs: Int,
    val loadPercent: Int,
    val category: String, // "Recommended", "Streaming", "P2P", "Free"
    val isPremium: Boolean = false,
    val isFavorite: Boolean = false,
    val mapXRatio: Float, // Relative X coordinate on world map canvas (0.0 to 1.0)
    val mapYRatio: Float  // Relative Y coordinate on world map canvas (0.0 to 1.0)
)

data class AppInfo(
    val packageName: String,
    val appName: String,
    val isBypassingVpn: Boolean
)

data class ProtocolOption(
    val name: String,
    val title: String,
    val description: String,
    val isRecommended: Boolean = false
)

enum class NavTab {
    HOME,
    SERVERS,
    MAP,
    SETTINGS
}
