package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppInfo
import com.example.data.ConnectionState
import com.example.data.DefaultServerData
import com.example.data.NavTab
import com.example.data.ProtocolOption
import com.example.data.ServerLocation
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlin.random.Random

data class VpnUiState(
    val connectionState: ConnectionState = ConnectionState.DISCONNECTED,
    val connectedDurationSeconds: Int = 0,
    val downloadSpeedMbps: Float = 0.0f,
    val uploadSpeedMbps: Float = 0.0f,
    val downloadHistory: List<Float> = listOf(0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f),
    val uploadHistory: List<Float> = listOf(0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f),
    val originalIp: String = "104.28.19.42",
    val activeIp: String = "104.28.19.42",
    val selectedServer: ServerLocation = DefaultServerData.initialServers[0],
    val servers: List<ServerLocation> = DefaultServerData.initialServers,
    val activeCategory: String = "All",
    val searchQuery: String = "",
    val activeTab: NavTab = NavTab.HOME,
    val selectedProtocol: String = "WireGuard",
    val protocols: List<ProtocolOption> = DefaultServerData.defaultProtocols,
    val killSwitchEnabled: Boolean = true,
    val netShieldEnabled: Boolean = true,
    val autoConnectWifi: Boolean = true,
    val splitTunnelingEnabled: Boolean = false,
    val splitTunnelApps: List<AppInfo> = DefaultServerData.defaultApps,
    val mapHighlightedServer: ServerLocation? = null,
    val totalDataUsedMb: Float = 0.0f
)

class VpnViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(VpnUiState())
    val uiState: StateFlow<VpnUiState> = _uiState.asStateFlow()

    private var connectionJob: Job? = null
    private var statsJob: Job? = null

    fun selectTab(tab: NavTab) {
        _uiState.update { it.copy(activeTab = tab) }
    }

    fun toggleConnection() {
        val currentState = _uiState.value.connectionState
        if (currentState == ConnectionState.DISCONNECTED) {
            startConnectProcess()
        } else {
            disconnect()
        }
    }

    private fun startConnectProcess() {
        connectionJob?.cancel()
        statsJob?.cancel()

        _uiState.update {
            it.copy(
                connectionState = ConnectionState.CONNECTING,
                downloadSpeedMbps = 0.0f,
                uploadSpeedMbps = 0.0f
            )
        }

        connectionJob = viewModelScope.launch {
            // Simulated delay of 2 seconds as requested
            delay(2000)

            _uiState.update {
                it.copy(
                    connectionState = ConnectionState.CONNECTED,
                    activeIp = it.selectedServer.ipAddress,
                    connectedDurationSeconds = 0,
                    totalDataUsedMb = Random.nextFloat() * 1.5f + 0.2f
                )
            }

            startConnectedCoroutines()
        }
    }

    private fun startConnectedCoroutines() {
        statsJob?.cancel()
        statsJob = viewModelScope.launch {
            var baseDownload = 12.4f
            var baseUpload = 4.8f

            // Adjust base speeds depending on category or ping
            if (_uiState.value.selectedServer.category == "Streaming") {
                baseDownload = 42.8f
                baseUpload = 14.2f
            } else if (_uiState.value.selectedServer.category == "P2P") {
                baseDownload = 38.5f
                baseUpload = 22.1f
            }

            while (_uiState.value.connectionState == ConnectionState.CONNECTED) {
                delay(1000)

                val dlJitter = (Random.nextFloat() * 4.0f) - 2.0f
                val ulJitter = (Random.nextFloat() * 1.8f) - 0.9f

                val newDl = (baseDownload + dlJitter).coerceIn(2.0f, 120.0f)
                val newUl = (baseUpload + ulJitter).coerceIn(0.5f, 50.0f)

                _uiState.update { state ->
                    val newDlHistory = (state.downloadHistory.drop(1) + newDl)
                    val newUlHistory = (state.uploadHistory.drop(1) + newUl)
                    val addedData = (newDl + newUl) / 8000f // Rough MB calculation per sec

                    state.copy(
                        connectedDurationSeconds = state.connectedDurationSeconds + 1,
                        downloadSpeedMbps = ((newDl * 10).toInt() / 10.0f),
                        uploadSpeedMbps = ((newUl * 10).toInt() / 10.0f),
                        downloadHistory = newDlHistory,
                        uploadHistory = newUlHistory,
                        totalDataUsedMb = state.totalDataUsedMb + addedData
                    )
                }
            }
        }
    }

    fun disconnect() {
        connectionJob?.cancel()
        statsJob?.cancel()

        _uiState.update {
            it.copy(
                connectionState = ConnectionState.DISCONNECTED,
                downloadSpeedMbps = 0.0f,
                uploadSpeedMbps = 0.0f,
                activeIp = it.originalIp,
                connectedDurationSeconds = 0,
                downloadHistory = List(10) { 0f },
                uploadHistory = List(10) { 0f }
            )
        }
    }

    fun selectServer(server: ServerLocation) {
        val wasConnected = _uiState.value.connectionState == ConnectionState.CONNECTED

        _uiState.update {
            it.copy(
                selectedServer = server,
                mapHighlightedServer = server
            )
        }

        if (wasConnected) {
            // Reconnect logic
            startConnectProcess()
        } else {
            _uiState.update { it.copy(activeIp = it.originalIp) }
        }
    }

    fun toggleFavorite(serverId: String) {
        _uiState.update { state ->
            val updatedServers = state.servers.map { server ->
                if (server.id == serverId) {
                    server.copy(isFavorite = !server.isFavorite)
                } else server
            }
            val updatedSelected = if (state.selectedServer.id == serverId) {
                state.selectedServer.copy(isFavorite = !state.selectedServer.isFavorite)
            } else state.selectedServer

            state.copy(
                servers = updatedServers,
                selectedServer = updatedSelected
            )
        }
    }

    fun setSearchQuery(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
    }

    fun setActiveCategory(category: String) {
        _uiState.update { it.copy(activeCategory = category) }
    }

    fun setProtocol(protocolName: String) {
        _uiState.update { it.copy(selectedProtocol = protocolName) }
    }

    fun setKillSwitch(enabled: Boolean) {
        _uiState.update { it.copy(killSwitchEnabled = enabled) }
    }

    fun setNetShield(enabled: Boolean) {
        _uiState.update { it.copy(netShieldEnabled = enabled) }
    }

    fun setAutoConnectWifi(enabled: Boolean) {
        _uiState.update { it.copy(autoConnectWifi = enabled) }
    }

    fun setSplitTunneling(enabled: Boolean) {
        _uiState.update { it.copy(splitTunnelingEnabled = enabled) }
    }

    fun toggleAppSplitTunnel(packageName: String) {
        _uiState.update { state ->
            val updated = state.splitTunnelApps.map { app ->
                if (app.packageName == packageName) {
                    app.copy(isBypassingVpn = !app.isBypassingVpn)
                } else app
            }
            state.copy(splitTunnelApps = updated)
        }
    }

    fun setMapHighlightedServer(server: ServerLocation?) {
        _uiState.update { it.copy(mapHighlightedServer = server) }
    }

    fun formatDuration(seconds: Int): String {
        val hrs = seconds / 3600
        val mins = (seconds % 3600) / 60
        val secs = seconds % 60
        return if (hrs > 0) {
            String.format("%02d:%02d:%02d", hrs, mins, secs)
        } else {
            String.format("%02d:%02d:%02d", 0, mins, secs)
        }
    }
}
