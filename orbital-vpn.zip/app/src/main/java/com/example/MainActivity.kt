package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.NavTab
import com.example.ui.navigation.BottomNavBar
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.MapScreen
import com.example.ui.screens.ServersScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.BackgroundDark
import com.example.ui.theme.OrbitalVpnTheme
import com.example.viewmodel.VpnViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            OrbitalVpnTheme {
                OrbitalVpnApp()
            }
        }
    }
}

@Composable
fun OrbitalVpnApp(
    viewModel: VpnViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    Scaffold(
        bottomBar = {
            BottomNavBar(
                activeTab = uiState.activeTab,
                onTabSelected = { viewModel.selectTab(it) }
            )
        },
        contentWindowInsets = WindowInsets.safeDrawing,
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundDark)
    ) { innerPadding ->
        val screenModifier = Modifier
            .fillMaxSize()
            .background(BackgroundDark)
            .padding(innerPadding)

        when (uiState.activeTab) {
            NavTab.HOME -> HomeScreen(
                uiState = uiState,
                onToggleConnection = { viewModel.toggleConnection() },
                onNavigateTab = { viewModel.selectTab(it) },
                formatDuration = { viewModel.formatDuration(it) },
                modifier = screenModifier
            )

            NavTab.SERVERS -> ServersScreen(
                uiState = uiState,
                onSelectServer = {
                    viewModel.selectServer(it)
                    viewModel.selectTab(NavTab.HOME)
                },
                onFavoriteToggle = { viewModel.toggleFavorite(it) },
                onSearchQueryChange = { viewModel.setSearchQuery(it) },
                onCategoryChange = { viewModel.setActiveCategory(it) },
                modifier = screenModifier
            )

            NavTab.MAP -> MapScreen(
                uiState = uiState,
                onSelectServer = { server ->
                    viewModel.selectServer(server)
                },
                modifier = screenModifier
            )

            NavTab.SETTINGS -> SettingsScreen(
                uiState = uiState,
                onProtocolSelect = { viewModel.setProtocol(it) },
                onToggleKillSwitch = { viewModel.setKillSwitch(it) },
                onToggleNetShield = { viewModel.setNetShield(it) },
                onToggleAutoConnectWifi = { viewModel.setAutoConnectWifi(it) },
                onToggleSplitTunneling = { viewModel.setSplitTunneling(it) },
                onToggleAppSplitTunnel = { viewModel.toggleAppSplitTunnel(it) },
                modifier = screenModifier
            )
        }
    }
}
